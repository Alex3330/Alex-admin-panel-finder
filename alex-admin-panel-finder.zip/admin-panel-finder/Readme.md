Alex Dhital's admin panel finder:-
coded in python a simple program to find the admin login page of any site
feel free to contact on facebook script can be modified as per wish and feel free to modify it :)
                                                    -RedVirus